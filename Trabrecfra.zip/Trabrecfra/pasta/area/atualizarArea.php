<HTML>
    <body>
        <form action = "atualizarArea.php" method = "POST">
        <p> escolha uma coluna: </p>
        <p><input type = "radio" name="coluna" value = "nomearea" > editar nome da area</p>
        <p><input type = "radio" name="coluna" value = "area" > editar area</p>

        <p><input type = "text" name="novo" value = "novo" > escreva a nova informação atualizada<br></p>
        </p>
        <p>Digite o nome:
        <p> <input type="text" name="nomearea" ><br></p> <br>
        </p>
        <input type="submit">
        </form>
    </body>
</HTML>
        <?php

                            
                                $host = 'localhost';
                                $user = 'root';
                                $password = '';
                                $database = 'alefe2';
                                
                                
                                $conn = new mysqli($host, $user, $password, $database);
                                
                                
                                $nomearea = $_POST['nomearea']; 
                                
                                $query = "SELECT *
                                    FROM area
                                    WHERE area.nomearea = '$nomearea';";
                                  $result = $conn->query($query);


                                  // Verificar se o nome foi encontrado
                                  if ($result->num_rows > 0) {
                                
                                    

                                $novo = $_POST["novo"];
                                $coluna = $_POST["coluna"];

                                    
                                        $row = $result->fetch_assoc();
                                        if ($coluna == "nomearea"){
                                            $query = "UPDATE area
                                            SET nomearea = '$novo'
                                            WHERE nomearea = '$nomearea'";
                                            $result = $conn -> query($query);
                                            echo("informaçõão editada com sucesso!");
                                        }
                                        
                                        else if ($coluna == "area"){
                                            $query = "UPDATE area
                                            SET area = '$novo'
                                            WHERE nomearea = '$nomearea'";
                                            $result = $conn -> query($query);
                                            echo("informaçõão editada com sucesso!");
                                        }
                                        else{
                                            echo "Não existe esta coluna na tabela area ";
                                        }
                                        
                                }
                                
                                   else {
                                    
                                    echo 'nome não encontrado.';
                                  }
                                
                                
                                
                                $conn->close();
                                
                                
                                ?>