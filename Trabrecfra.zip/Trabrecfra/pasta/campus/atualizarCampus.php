<HTML>
    <body>
        <form action = "atualizarCampus.php" method = "POST">
        <p> escolha uma coluna: </p>
        <p><input type = "radio" name="coluna" value = "nomecampus" > editar nome do campus</p>
        <p><input type = "radio" name="coluna" value = "cep" > editar cep</p>

        <p><input type = "text" name="novo" value = "novo" > escreva a nova informação atualizada<br></p>
        </p>
        <p>Digite o nome:
        <p> <input type="text" name="nomecampus" ><br></p> <br>
        </p>
        <input type="submit">
        </form>
    </body>
</HTML>
        <?php 

                            
                                $host = 'localhost';
                                $user = 'root';
                                $password = '';
                                $database = 'alefe2';
                                
                                
                                $conn = new mysqli($host, $user, $password, $database);
                                
                                
                                $nomecampus = $_POST['nomecampus']; 
                                
                                $query = "SELECT *
                                    FROM campus
                                    WHERE campus.nomecampus = '$nomecampus';";
                                  $result = $conn->query($query);


                                  // Verificar se o nome foi encontrado
                                  if ($result->num_rows > 0) {
                                
                                    

                                $novo = $_POST["novo"];
                                $coluna = $_POST["coluna"];

                                    
                                        $row = $result->fetch_assoc();
                                        if ($coluna == "nomecampus"){
                                            $query = "UPDATE campus
                                            SET nomecampus = '$novo'
                                            WHERE nomecampus = '$nomecampus'";
                                            $result = $conn -> query($query);
                                            echo("informaçõão editada com sucesso!");
                                        }
                                        
                                        else if ($coluna == "cep"){
                                            $query = "UPDATE campus
                                            SET cep = '$novo'
                                            WHERE nomecampus = '$nomecampus'";
                                            $result = $conn -> query($query);
                                            echo("informaçõão editada com sucesso!");
                                        }
                                        else{
                                            echo "Não existe esta coluna na tabela campus ";
                                        }
                                        
                                }
                                
                                   else {
                                    
                                    echo 'nome não encontrado.';
                                  }
                                
                                
                                
                                $conn->close();
                                
                                
                                ?>