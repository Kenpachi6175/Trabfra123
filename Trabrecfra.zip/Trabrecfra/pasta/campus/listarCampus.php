<html>
    <body>
        <form  action="listarCampus.php" method="post">
<h1>PROCURE UM CAMPUS: </h1><br><p>
            <p>Nome: <input type="text" name="nomecampus" required><br></p>
            
           

            <input type="submit">
        </form>
    </body>
</html><?php 
                                $host = 'localhost';
                                $user = 'root';
                                $password = '';
                                $database = 'alefe2';
                                
                                
                                $conn = new mysqli($host, $user, $password, $database);
                                
                                
                                $nomecampus = $_POST['nomecampus']; 

                                 
                                  $query = "SELECT *
                                    FROM campus
                                    WHERE campus.nomecampus = '$nomecampus';";
                                  $result = $conn->query($query);


                                  
                                  if ($result->num_rows > 0) {
                                    $query ="SELECT *
                                    FROM campus
                                    WHERE campus.nomecampus = '$nomecampus';";
                                    
                                    $result = $conn -> query($query);
                                    ?> <table >
                                    <thead>
                                    <tr>
                                    <th>    /nome campus/    </th>
                                    <th>    /CEP/    </th>
                                   
                                    
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php while ($row = $result->fetch_assoc()) { ?>
                                    <tr>
                                    <td>     <?php echo $row["nomecampus"]; ?>     </td>
                                    <td>     <?php echo $row["cep"]; ?>     </td>

                                    
                                    <td>
                                    
                                     
                                    </td>
                                    </tr>
                                    <?php } ?>
                                    </tbody>
                                    </table>
                                    <?php
                                    }
                                    else {
                                    echo 'nome não encontrado.';
                                    }
                                
                                $conn->close();
?>