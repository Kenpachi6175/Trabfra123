<HTML>
    <body>
        <form action = "atualizarCurso.php" method = "POST">
        <p> escolha uma coluna: </p>
        <p><input type = "radio" name="coluna" value = "nomecurso" > editar nome do curso</p>
        <p><input type = "radio" name="coluna" value = "areacurso" >   editar area do curso</p>
        <p><input type = "radio" name="coluna" value = "campuscurso" >  editar campus do curso</p>
        <p><input type = "radio" name="coluna" value = "nota" > editar nota</p>

        <p><input type = "text" name="novo" value = "novo" > escreva a nova informação atualizada<br></p>
        </p>
        <p>Digite o nome:
        <p> <input type="text" name="nomecurso" ><br></p> <br>
        </p>
        <input type="submit">
        </form>
    </body>
</HTML>
        <?php 

$host = 'localhost';
$user = 'root';
$password = '';
$database = 'alefe2';

$conn = new mysqli($host, $user, $password, $database);

$nomecurso = $_POST['nomecurso'];
$novo = $_POST["novo"];
$coluna = $_POST["coluna"];

$query = "SELECT *
            FROM curso
            WHERE curso.nomecurso = '$nomecurso';";
$result = $conn->query($query);

// Verificar se o nome foi encontrado
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();

    if ($coluna == "nomecurso") {
        $query = "UPDATE curso
                    SET nomecurso = '$novo'
                    WHERE nomecurso = '$nomecurso'";
        $result = $conn->query($query);
        echo("informação editada com sucesso!");


    } else if ($coluna == "areacurso") {
        $query = "UPDATE curso
                    SET areacurso = '$novo'
                    WHERE nomecurso = '$nomecurso'";
        $result = $conn->query($query);
        echo("informação editada com sucesso!");


    } else if ($coluna == "campuscurso") {
        $query = "UPDATE curso
                    SET campuscurso = '$novo'
                    WHERE nomecurso = '$nomecurso'";
        $result = $conn->query($query);
        echo("informação editada com sucesso!");


    } else if ($coluna == "nota") {
        $query = "UPDATE curso
                    SET nota = '$novo'
                    WHERE nomecurso = '$nomecurso'";
        $result = $conn->query($query);
        echo("informação editada com sucesso!");


    } else {
        echo "Não existe esta coluna na tabela curso";
    }

    
} else {
    echo 'nome não encontrado.';
}

$conn->close();
?>