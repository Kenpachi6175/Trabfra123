<?php
$path = 'http://' . $_SERVER["HTTP_HOST"] . '/devweb22023';



session_start();
/*if(isset($_SESSION['status'])==true){
    header('Location: ../index.php');
}
if(isset($_SESSION['tentativa']) ==true){
    echo "<script>alert('Erro ao fazer login!');</script>";
    unset($_SESSION['tentativa']);
}*/
?>
<!doctype html>  
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Signin Template for Bootstrap</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/4.0/examples/sign-in/">

    <!-- Bootstrap core CSS -->
    <link href="bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
    <form class="form-signin" method="post" action=" logar.php">
      <img class="mb-4" src="../arquivos/imagens/iff.png" alt="" width="72" height="72">
      <h1 class="h3 mb-3 font-weight-normal">Partiu logar</h1>
      <label for="inputEmail" class="sr-only">Email </label>
      <input type="email" name="email" id="inputEmail" class="form-control" placeholder="Email " required autofocus>
      <label for="inputPassword" class="sr-only">senha</label>
      <input type="password" name="password" id="inputPassword" class="form-control" placeholder="senha" required>
      <a href="cadastro.php">Faça um cadastro</a> <!-- Link para cadastrar.php -->
      <div class="checkbox mb-3">
        <label>
          <input type="checkbox" value="remember-me"> Lembrar senha
        </label>
      </div>
      <button class="btn btn-lg btn-primary btn-block" type="submit">login</button>
      <p class="mt-5 mb-3 text-muted">&copy; 2017-2018</p>
    </form>
  </body>
</html>