<?php

session_start();

try {
    $conexao = new PDO("mysql:host=localhost;dbname=alefe2", "root", "");
    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ocorreu um erro inesperado: " . $e->getMessage());
}

$logado = false;

try {
    $email = $_POST['email'];
    $senha = $_POST['password'];

    $sql = "SELECT * FROM pessoa WHERE email = :email";












    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $pessoa = $stmt->fetch();
        if ($pessoa) {
            $_SESSION["login"] = $email;
            $_SESSION["status"] = true;
            $logado = true;
            
            
            setcookie("boas_vindas", "Bem-vindo($email) ao sistema!", time() + 3600, "/");
            
            header('Location: ../index.php');
            exit();
        }
    }

    $_SESSION["tentativa"] = true;
    header('Location: login.php');
    exit();
} catch (PDOException $e) {
    echo "Ocorreu um erro ao executar a consulta: " . $e->getMessage();
    exit();
}

?>