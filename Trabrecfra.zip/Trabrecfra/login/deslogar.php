<?php 
session_start();
session_unset();
session_destroy();
header('Location: login.php');
setcookie("boas_vindas", "Bem-vindo$email ao sistema!", time() - 3600, "/");
            
            header('Location: ../index.php');
            exit();
?>