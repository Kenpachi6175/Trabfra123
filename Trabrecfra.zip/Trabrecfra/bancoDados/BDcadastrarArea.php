<?php

function conectar()
{
    $pdo = new PDO("mysql:host=localhost;dbname=alefe2", "root", "");
    return $pdo;
}

function cadastrar($nomearea, $area)
{
    $pdo = conectar(); 
    $stmt = $pdo->prepare("INSERT INTO area(nomearea, area) VALUES(?, ?)");
    $stmt->bindParam(1, $nomearea);
    $stmt->bindParam(2, $area);

    $stmt->execute();
}
?>
