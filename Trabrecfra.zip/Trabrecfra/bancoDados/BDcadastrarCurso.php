<?php

function conectar()
{
    $pdo = new PDO("mysql:host=localhost;dbname=alefe2", "root", "");
    return $pdo;
}
function cadastrar($nomecurso, $areacurso, $campuscurso, $nota)
{
    $pdo = conectar();  
    $stmt = $pdo->prepare("INSERT INTO curso(nomecurso, areacurso,campuscurso,nota) VALUES(?, ?, ?, ?)");
    $stmt->bindParam(1, $nomecurso);
    $stmt->bindParam(2, $areacurso);
    $stmt->bindParam(3, $campuscurso);
    $stmt->bindParam(4, $nota);

    $stmt->execute();   
} 
?> 
