<?php

function conectar()
{
    $pdo = new PDO("mysql:host=localhost;dbname=alefe2", "root", "");
    return $pdo;
}

function cadastrarPessoa($email, $senha)
{
    $pdo = conectar();  
    $stmt = $pdo->prepare("INSERT INTO pessoa(email, senha) VALUES(?, ?)");
    $stmt->bindParam(1, $email);
    $stmt->bindParam(2, $senha);

    $stmt->execute();   
}

?>
