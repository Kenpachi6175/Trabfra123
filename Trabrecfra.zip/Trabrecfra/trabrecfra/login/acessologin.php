<?php
$email = $_POST["email"];
$password = $_POST["password"];
// Conectando ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pessoa";

$conn = mysqli_connect($servername, $username, $password, $dbname);

// Verificando se a conexão foi bem sucedida
if (!$conn) {
    die("Conexão falhou: " . mysqli_connect_error());
}else{
echo "Conexão bem sucedida";}

// Verificando se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // Processando os dados do formulário
  $email = $_POST["email"];
  $password = $_POST["password"];

  // Verificando se o nome de usuário e senha estão corretos
  $sql = "SELECT * FROM pessoa WHERE email = '$email' AND senha = '$password'";
  $result = $conn->query($sql);
  if ($result->num_rows == 1) {
      echo $result->num_rows;
    // Iniciando uma sessão e redirecionando para a página de destino
    session_start();
    $_SESSION["email"] = $email;
    $_SESSION["password"] = $password;
    header("Location: ../menu.php");
  } else {
    // Redirecionando de volta para a página de login
    header("Location: login.php");
   
  }

  $conn->close();
}
?>