<?php
                                require_once "../bancoDados/BDcadastrarCurso.php";
                        
                                
                                $nomecurso = $_POST["nomecurso"];
                                $areacurso = $_POST["areacurso"];
                                $campuscurso = $_POST["campuscurso"];
                                $nota = $_POST["nota"];
                            
                        
                                echo "<br>nomecurso: \n<br>".$nomecurso;
                                echo "<br>areacurso : \n<br>".$areacurso;
                                echo "<br>campuscurso: \n<br>".$campuscurso;
                                echo "<br>nota: \n<br>".$nota;
                                
                                cadastrar($nomecurso, $areacurso, $campuscurso, $nota);
                                ?>      