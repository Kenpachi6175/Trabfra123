<?php
require_once "../bancoDados/BDcadastrarPessoa.php";

$email = $_POST["email"];
$senha = $_POST["password"];

echo "Cadastro efetuado com sucesso";


cadastrarPessoa($email, $senha);

// Redirecionar para a página de login após o cadastro
header("Location: ../login/login.php");
exit;
?>


<?php
session_start();
require_once "../bancoDados/BDcadastrarPessoa.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST["email"];
    $senha = $_POST["password"];

    // Verificar as credenciais no banco de dados
    if (verificarCredenciais($email, $senha)) {
        // Credenciais corretas, iniciar sessão
        $_SESSION["email"] = $email;

        // Redirecionar para o menu
        header("Location: menu.php");
        exit;
    } else {
        // Credenciais inválidas, exibir mensagem de erro
        echo "Credenciais inválidas. Tente novamente.";
    }
}
?>






