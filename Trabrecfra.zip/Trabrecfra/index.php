

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>IFMS</title>

    <!--Adicionando Framework Bootstrap CSS e JS-->
    <link href="./arquivos/css/bootstrap.min.css" rel="stylesheet">
    <script src="./arquivos/js/bootstrap.bundle.min.js"></script>

</head>

<body>
    <!-- Adicionando menu redirecionando o usuario para outra pagina, isto faz o menu aparecer-->
    <?php include("./menu.php") ?>

    <!--Adicionando um espaçamento horizontal e vertical para a div e auto alinhamento centro.-->
    <!-- px se refere a preenchimento horizontal a esquerda e direita do elemento.-->
    <!-- py se refere a preenchimento vertical acima e abaixo do elemento. -->
    <!-- pt-md se refere a preenchimento de margem superior e preenchimento superior para telas medias e maiores (padding top) -->
    <!-- pb-md se refere a preenchimento de margem inferior e preenchimento inferior para telas medias e maiores (padding bottom) -->
    <div class="px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">

        <!--Autoregulagem de tamanho fontes-->
        <h1 class="display-4">Desenvolvimento Web 2</h1>
        <!-- Aplica um estilo fonte diferente-->
        <p class="lead">Objetivo: Desenvolver aplicações WEB utilizando servidor apache, linguagem PHP, biblioteca
            jQuery, acesso a banco de dados e técnicas de orientação a objetos seguindo o padrão MVC para desenvolver
            aplicações completas.</p>
            
    </div>

    <!-- container(bootstrap) centraliza o conteudo -->
    <div class="container">
        <!-- row cria uma linha horizontal na qual as colunas sao colocadas lado a lado -->
        <div class="row">
            <!-- a coluna ocupará 25% (3/12) da largura total do container pai (responsividade para dar espaço a imagem).-->
            <!-- md se refere a dispositos de tamanho medio.-->
            <div class="col-md-3">
            </div>
            <!--a coluna ocupará 50% (6/12) da largura total do container pai.-->
            <div class="col-md-6">
                <!--chamada carousel-->
                <!-- classe slide, o id carouselExampleInterval e data-bs-ride define o comportamento de 
                animação de transição entre as imagens -->
                <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
                    <!--carousel Inner é responsavel por aplicar o estilo de largura e altura adequado aos slides -->
                    <div class="carousel-inner">
                        <!--timer carousel-->
                        <!--carousel-item define o estilo básico para um slide, 
                        como a largura, altura, margens e outros estilos de posicionamento,
                    quando possui a classe active, ele é exibido como o slide atual no carrossel-->
                        <div class="carousel-item active" data-bs-interval="2000000">
                            <img src="./arquivos/imagens/ifms1.png" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item" data-bs-interval="2000000">
                            <img src="./arquivos/imagens/ifms2.jpeg" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="./arquivos/imagens/ifms3.jpeg" class="d-block w-100" alt="...">
                        </div>
                    </div>

                    <!-- botões do carousel-->
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                        
                    </button>
                </div>
            </div>
        </div>

       
            <!-- chamada da barra de navegacao de paginas -->
            <div class="row mt-5">
                
                <div class="col-md-3">
                    
                </div>
            </div>
            <div class="col-md-3 mx-auto text-center">
                <nav aria-label="Page navigation example">
                    <ul class="pagination">
                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
</body>

</html>